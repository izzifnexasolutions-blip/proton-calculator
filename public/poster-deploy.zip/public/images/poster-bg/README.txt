LATAR AI (Higgsfield)
=====================

Letak gambar latar di sini dengan nama mengikut id model:

    saga.jpg      persona.jpg    s70.jpg     x50.jpg
    x70.jpg       x90.jpg        emas5.jpg   emas7ev.jpg  emas7phev.jpg

Enjin poster akan guna fail ini sebagai latar penuh (dengan lapisan gelap
supaya teks kekal jelas). Kalau fail tiada, poster guna latar warna tema.

Saiz disyorkan: 1080x1350 (feed) atau 1080x1920 (story), JPEG kualiti 85.
